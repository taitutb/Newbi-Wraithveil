window.__require = function t(e, n, r) {
function a(s, i) {
if (!n[s]) {
if (!e[s]) {
var c = s.split("/");
c = c[c.length - 1];
if (!e[c]) {
var l = "function" == typeof __require && __require;
if (!i && l) return l(c, !0);
if (o) return o(c, !0);
throw new Error("Cannot find module '" + s + "'");
}
s = c;
}
var u = n[s] = {
exports: {}
};
e[s][0].call(u.exports, function(t) {
return a(e[s][1][t] || t);
}, u, u.exports, t, e, n, r);
}
return n[s].exports;
}
for (var o = "function" == typeof __require && __require, s = 0; s < r.length; s++) a(r[s]);
return a;
}({
LoadGameController: [ function(t, e, n) {
"use strict";
cc._RF.push(e, "89e3bULnINAO5LStk1zefH7", "LoadGameController");
var r, a = this && this.__extends || (r = function(t, e) {
return (r = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
})(t, e);
}, function(t, e) {
r(t, e);
function n() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (n.prototype = e.prototype, new n());
}), o = this && this.__decorate || function(t, e, n, r) {
var a, o = arguments.length, s = o < 3 ? e : null === r ? r = Object.getOwnPropertyDescriptor(e, n) : r;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) s = Reflect.decorate(t, e, n, r); else for (var i = t.length - 1; i >= 0; i--) (a = t[i]) && (s = (o < 3 ? a(s) : o > 3 ? a(e, n, s) : a(e, n)) || s);
return o > 3 && s && Object.defineProperty(e, n, s), s;
}, s = this && this.__awaiter || function(t, e, n, r) {
return new (n || (n = Promise))(function(a, o) {
function s(t) {
try {
c(r.next(t));
} catch (t) {
o(t);
}
}
function i(t) {
try {
c(r.throw(t));
} catch (t) {
o(t);
}
}
function c(t) {
t.done ? a(t.value) : (e = t.value, e instanceof n ? e : new n(function(t) {
t(e);
})).then(s, i);
var e;
}
c((r = r.apply(t, e || [])).next());
});
}, i = this && this.__generator || function(t, e) {
var n, r, a, o, s = {
label: 0,
sent: function() {
if (1 & a[0]) throw a[1];
return a[1];
},
trys: [],
ops: []
};
return o = {
next: i(0),
throw: i(1),
return: i(2)
}, "function" == typeof Symbol && (o[Symbol.iterator] = function() {
return this;
}), o;
function i(t) {
return function(e) {
return c([ t, e ]);
};
}
function c(o) {
if (n) throw new TypeError("Generator is already executing.");
for (;s; ) try {
if (n = 1, r && (a = 2 & o[0] ? r.return : o[0] ? r.throw || ((a = r.return) && a.call(r), 
0) : r.next) && !(a = a.call(r, o[1])).done) return a;
(r = 0, a) && (o = [ 2 & o[0], a.value ]);
switch (o[0]) {
case 0:
case 1:
a = o;
break;

case 4:
s.label++;
return {
value: o[1],
done: !1
};

case 5:
s.label++;
r = o[1];
o = [ 0 ];
continue;

case 7:
o = s.ops.pop();
s.trys.pop();
continue;

default:
if (!(a = s.trys, a = a.length > 0 && a[a.length - 1]) && (6 === o[0] || 2 === o[0])) {
s = 0;
continue;
}
if (3 === o[0] && (!a || o[1] > a[0] && o[1] < a[3])) {
s.label = o[1];
break;
}
if (6 === o[0] && s.label < a[1]) {
s.label = a[1];
a = o;
break;
}
if (a && s.label < a[2]) {
s.label = a[2];
s.ops.push(o);
break;
}
a[2] && s.ops.pop();
s.trys.pop();
continue;
}
o = e.call(t, s);
} catch (t) {
o = [ 6, t ];
r = 0;
} finally {
n = a = 0;
}
if (5 & o[0]) throw o[1];
return {
value: o[0] ? o[1] : void 0,
done: !0
};
}
};
Object.defineProperty(n, "__esModule", {
value: !0
});
var c = cc._decorator, l = c.ccclass, u = c.property;
function p(t, e) {
for (var n = t.split("."), r = e.split("."), a = 0; a < n.length; ++a) {
var o = parseInt(n[a]), s = parseInt(r[a] || "0");
if (o !== s) return o - s;
}
return r.length > n.length ? -1 : 0;
}
var f = function(t) {
a(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.loadingSprite = null;
e.loadingLabel = null;
e.lbInfo = null;
e._updating = !1;
e._canRetry = !1;
e._storagePath = "";
e.stringHost = "";
e._am = null;
e._checkListener = null;
e._updateListener = null;
e.count = 0;
e.gameInfo = null;
e.ERROR_NO = 0;
e.ERROR_CHECK_DOWNLOAD = 1;
e.ERROR_DOWNLOAD = 2;
e.ERROR_GETINFO = 3;
e.ERROR_LOAD_SCENE = 4;
e.errorCase = e.ERROR_NO;
return e;
}
e.prototype.onLoad = function() {
if (jsb) {
this._storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + "remote-asset";
this._am = new jsb.AssetsManager("", this._storagePath, p);
this._am.setVerifyCallback(function(t, e) {
var n = e.compressed, r = e.md5, a = e.path;
e.size;
if (n) {
cc.log("Verification passed : " + a);
return !0;
}
cc.log("Verification passed : " + a + " (" + r + ")");
return !0;
});
}
};
e.prototype.onDestroy = function() {
if (this._updateListener) {
this._am.setEventCallback(null);
this._updateListener = null;
}
};
e.prototype.start = function() {
return s(this, void 0, void 0, function() {
var t = this;
return i(this, function() {
this.schedule(function() {
t.count += .01;
t.updateProcess(t.count);
t.count >= 1 && t.loadMyGame();
}, .03);
this.onCheckGame("https://config.trum8899.store/");
return [ 2 ];
});
});
};
e.prototype.loadMyGame = function() {
this.unscheduleAllCallbacks();
cc.director.loadScene("HomeScene");
};
e.prototype.onCheckGame = function(t) {
this.unscheduleAllCallbacks();
this.stringHost = t;
this.hotUpdate();
};
e.prototype.loadCustomManifest = function(t) {
var e, n = new jsb.Manifest((e = t, JSON.stringify({
packageUrl: e + "/",
remoteManifestUrl: e + "/project.manifest",
remoteVersionUrl: e + "/version.manifest",
version: "0.0.0",
assets: {},
searchPaths: []
})), this._storagePath);
this._am.loadLocalManifest(n, this._storagePath);
};
e.prototype.updateCb = function(t) {
var e = !1, n = !1;
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
cc.log("No local manifest file found, hot update skipped.");
n = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var r = t.getDownloadedBytes() / t.getTotalBytes();
t.getMessage();
this.updateProcess(r);
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
cc.log("Fail to download manifest file, hot update skipped.");
n = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
cc.log("Already up to date with the latest remote version.");
e = !0;
try {
cc.director.loadScene("Loading");
} catch (t) {}
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
cc.log("Update finished. " + t.getMessage());
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
cc.log("Update failed. " + t.getMessage());
this._updating = !1;
this._canRetry = !0;
n = !0;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
cc.log("Asset update error: " + t.getAssetId() + ", " + t.getMessage());
n = !0;
break;

case jsb.EventAssetsManager.ERROR_DECOMPRESS:
cc.log(t.getMessage());
n = !0;
}
if (n) {
this._am.setEventCallback(null);
this._updateListener = null;
this._updating = !1;
this.loadMyGame();
}
if (e) {
this._am.setEventCallback(null);
this._updateListener = null;
var a = jsb.fileUtils.getSearchPaths(), o = this._am.getLocalManifest().getSearchPaths();
Array.prototype.unshift.apply(a, o);
cc.sys.localStorage.setItem("HotUpdateSearchPaths", JSON.stringify(a));
cc.log(JSON.stringify(o));
setTimeout(function() {
cc.game.restart();
}, 500);
}
};
e.prototype.hotUpdate = function() {
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCb.bind(this));
this.loadCustomManifest(this.stringHost);
this._am.update();
this._updating = !0;
}
};
e.prototype.updateProcess = function(t) {
cc.log("Updated file: " + t);
this.loadingSprite.fillRange = t;
this.loadingLabel.string = "Update " + Math.round(100 * t) + "%";
};
o([ u(cc.Sprite) ], e.prototype, "loadingSprite", void 0);
o([ u(cc.Label) ], e.prototype, "loadingLabel", void 0);
o([ u(cc.Label) ], e.prototype, "lbInfo", void 0);
return o([ l ], e);
}(cc.Component);
n.default = f;
cc._RF.pop();
}, {} ]
}, {}, [ "LoadGameController" ]);